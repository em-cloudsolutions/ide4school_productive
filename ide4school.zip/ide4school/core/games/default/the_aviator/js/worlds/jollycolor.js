/* --- Jolly Color --- */

// the jollycolor indicates each color in the game
const JollyColor = '#f5f5f5'
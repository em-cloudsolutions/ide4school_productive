⚠️

These images were purchased on [Adobe Stock](https://stock.adobe.com/) and are not under the MIT license. If you want to use them for personal purposes, I suggest you visit the website to learn how to get a [license](https://stock.adobe.com/license-terms).
<?php
if (!defined('IN_SITE')) { echo "Zugriff verweigert!"; die(); }
if(!$db->isUserLoggedIn()) {
    header("Location: not_authorized");
}
if(!isset($_SESSION['login_state']) && $db->getMFAMethodsFromUser($_SESSION['user_id']) != NULL) {
    header("Location: 2fa");
}

$getCurrentUserData = $db->getCurrentUserInformations();

// Submission view -> with complete filepath 
if(isset($_POST['showSubmission'])) {
    $filepath = $_POST['show_submission_path'];
}

// Filemanager view -> without complete filepath
if(isset($_POST['filepath'])) {
            $filepath = $_POST['filepath'];    
}

if(isset($_POST["setupEnviroment"]))
{
    $ide_code = $_POST['ide_code'];
    if($ide_code == '1') {
        $ext = "html";
    }
    elseif($ide_code == "2") {
        $ext = "py";
    }
    else {
        $ext = "new";
    }
}


if(isset($_POST["saveFile"]))
{
    $writedata = $_POST['file_content'];
    $writepath = $_POST['file_path'];
    if(file_put_contents($writepath, $writedata)){
        $write_results = "1";
    }
    else {
        $write_results = "0";
    }
    if ($write_results == "0"){
        echo '<h1 style="color: red; text-align: center;">Datei konnte nicht gespeichert werden.</h1>';
        sleep(3);
        header("Location: disk&return");
    }
    else {
       header("Location: disk&return"); 
    }
};

if(isset($_POST["saveNewFile"]))
{
    $writedata = $_POST['file_content'];
    $writepath_raw = $_POST['file_path'];
    $writename = $_POST['file_name'];
    $writepath = $writepath_raw . "/" . $writename;
    $new_file = fopen($writepath,"w");
    fwrite($new_file,"");
    fclose($new_file);
    if(file_put_contents($writepath, $writedata)){
        $write_results = "1";
    }
    else {
        $write_results = "0";
    }
    if ($write_results == "0"){
        echo '<h1 style="color: red; text-align: center;">Datei konnte nicht gespeichert werden.</h1>';
        sleep(3);
        header("Location: disk&return");
    }
    else {
       header("Location: disk&return"); 
    }
};

if(isset($filepath)) {
    $ext = pathinfo($filepath, PATHINFO_EXTENSION);
    $file_name = pathinfo($filepath, PATHINFO_FILENAME) . '.' . $ext;
    $file_content = file_get_contents($filepath);
}

if($ext == "html") {
    include('core/ide/html/tryit.3.7.php');
}
elseif($ext == "py") {
    include('editor_main.php');
}
else {
    include('core/ide/judge0/index.php');
}


?>